import { useEffect, useMemo, useState } from "react";
import { Circle, MapContainer, Marker, TileLayer, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { AlertTriangle, Check, Crosshair, Loader2, MapPin, Pencil, Search } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
  distanceKm,
  findNearestZone,
  getActiveZones,
  OUT_OF_ZONE_MESSAGE,
  type DeliveryZone,
} from "@/lib/serviceArea";
import { geocodeAddress, reverseGeocode } from "@/lib/geocode";

// Default centre when we have nothing to anchor on (Cape Town).
const FALLBACK_CENTRE: [number, number] = [-33.9249, 18.4241];

const markerIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [0, -41],
  shadowSize: [41, 41],
});

interface AddressMapPickerProps {
  onConfirm: (result: { address: string; lat: number; lng: number }) => void;
  initialAddress?: string;
  initialCoords?: { lat: number; lng: number } | null;
}

const RecenterMap = ({ position }: { position: [number, number] }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(position, Math.max(map.getZoom(), 14), { animate: true });
  }, [map, position]);
  return null;
};

const ClickHandler = ({ onPick }: { onPick: (lat: number, lng: number) => void }) => {
  useMapEvents({
    click(e) {
      onPick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
};

export const AddressMapPicker = ({
  onConfirm,
  initialAddress,
  initialCoords,
}: AddressMapPickerProps) => {
  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [position, setPosition] = useState<[number, number]>(
    initialCoords && Number.isFinite(initialCoords.lat) && Number.isFinite(initialCoords.lng)
      ? [initialCoords.lat, initialCoords.lng]
      : FALLBACK_CENTRE,
  );
  const [address, setAddress] = useState<string>("");
  const [search, setSearch] = useState<string>("");
  const [loadingAddress, setLoadingAddress] = useState(false);
  const [locating, setLocating] = useState(false);
  const [searching, setSearching] = useState(false);
  const [confirming, setConfirming] = useState(false);

  // Load zones for the visualisation circles.
  useEffect(() => {
    let alive = true;
    getActiveZones().then((z) => {
      if (alive) setZones(z);
    });
    return () => {
      alive = false;
    };
  }, []);

  // Reverse-geocode the pin (debounced).
  useEffect(() => {
    setLoadingAddress(true);
    setAddress("");
    setConfirming(false);
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      const result = await reverseGeocode(position[0], position[1]);
      if (cancelled) return;
      if (result?.address) setAddress(result.address);
      setLoadingAddress(false);
    }, 500);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [position]);

  // On first mount, try to centre on initial address (if no coords given).
  useEffect(() => {
    if (initialCoords) return;
    const q = initialAddress?.trim();
    if (!q) return;
    geocodeAddress(q).then((c) => {
      if (c) setPosition([c.lat, c.lng]);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setPosition([pos.coords.latitude, pos.coords.longitude]);
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const q = search.trim();
    if (!q) return;
    setSearching(true);
    try {
      const c = await geocodeAddress(q);
      if (c) setPosition([c.lat, c.lng]);
    } finally {
      setSearching(false);
    }
  };

  const matchedZone = useMemo(
    () => findNearestZone(position[0], position[1], zones),
    [position, zones],
  );
  const inRange = matchedZone !== null;

  // Distance to nearest zone centre (even if out of range), for hint copy.
  const nearestCentreDistance = useMemo(() => {
    if (zones.length === 0) return null;
    let min = Infinity;
    for (const z of zones) {
      if (z.lat == null || z.lng == null) continue;
      const d = distanceKm(z.lat, z.lng, position[0], position[1]);
      if (d < min) min = d;
    }
    return Number.isFinite(min) ? min : null;
  }, [position, zones]);

  return (
    <div className="flex h-full flex-col">
      <form onSubmit={handleSearch} className="flex gap-2 px-4 pb-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search a place, e.g. Mfuleni Drive"
            className="pl-9"
          />
        </div>
        <Button
          type="submit"
          disabled={searching || !search.trim()}
          size="sm"
          className="h-10 px-4"
        >
          {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : "Go"}
        </Button>
      </form>

      <div
        className="relative mx-4 overflow-hidden rounded-2xl border border-border"
        style={{ height: 280 }}
      >
        <MapContainer
          center={position}
          zoom={14}
          scrollWheelZoom
          style={{ height: "100%", width: "100%" }}
        >
          <TileLayer
            attribution='&copy; <a href="https://osm.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {/* Show a circle for each delivery zone */}
          {zones.map((z) =>
            z.lat != null && z.lng != null ? (
              <Circle
                key={z.id}
                center={[z.lat, z.lng]}
                radius={Number(z.radius_km) * 1000}
                pathOptions={{
                  color:
                    matchedZone?.zone.id === z.id ? "hsl(24 95% 53%)" : "hsl(24 95% 53% / 0.6)",
                  weight: matchedZone?.zone.id === z.id ? 2 : 1.2,
                  fillColor: "hsl(24 95% 53%)",
                  fillOpacity: matchedZone?.zone.id === z.id ? 0.08 : 0.04,
                  dashArray: matchedZone?.zone.id === z.id ? undefined : "4 6",
                }}
              />
            ) : null,
          )}
          <Marker
            position={position}
            icon={markerIcon}
            draggable
            eventHandlers={{
              dragend: (e) => {
                const m = e.target as L.Marker;
                const ll = m.getLatLng();
                setPosition([ll.lat, ll.lng]);
              },
            }}
          />
          <ClickHandler onPick={(lat, lng) => setPosition([lat, lng])} />
          <RecenterMap position={position} />
        </MapContainer>

        <button
          type="button"
          onClick={handleUseMyLocation}
          disabled={locating}
          className="absolute right-3 top-3 z-[1000] inline-flex h-10 w-10 items-center justify-center rounded-full bg-card text-foreground shadow-lg ring-1 ring-border hover:bg-accent disabled:opacity-60"
          aria-label="Use my location"
        >
          {locating ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Crosshair className="h-4 w-4" />
          )}
        </button>
      </div>

      <p className="px-4 pt-2 text-[11px] text-muted-foreground">
        Tap the map or drag the pin to your exact spot. Orange circles are delivery zones.
      </p>

      <div className="mt-3 space-y-2 px-4 pb-4">
        <div className="rounded-2xl border border-border bg-card p-3">
          <div className="flex items-start gap-2">
            <MapPin className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
            <div className="flex-1 min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                Selected location
              </p>
              <p className="mt-0.5 text-sm text-foreground">
                {loadingAddress ? "Finding address…" : address || "Move the pin to pick an address"}
              </p>
              {matchedZone && (
                <p className="mt-1 text-[11px] font-bold text-primary">
                  ✓ Inside {matchedZone.zone.name} · R{matchedZone.zone.delivery_fee} delivery
                </p>
              )}
            </div>
          </div>
        </div>

        {!inRange && address && !loadingAddress && (
          <div
            role="alert"
            className="flex items-start gap-3 rounded-2xl border-2 border-destructive/40 bg-destructive/10 p-3 animate-in fade-in slide-in-from-top-1"
          >
            <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl bg-destructive text-destructive-foreground">
              <AlertTriangle className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-destructive">{OUT_OF_ZONE_MESSAGE}</p>
              {nearestCentreDistance != null && (
                <p className="mt-0.5 text-[11px] leading-relaxed text-foreground">
                  Nearest zone centre is {nearestCentreDistance.toFixed(1)} km away.
                </p>
              )}
            </div>
          </div>
        )}

        {!confirming ? (
          <Button
            type="button"
            onClick={() => setConfirming(true)}
            disabled={!address || loadingAddress || !inRange}
            className={cn("h-12 w-full rounded-full text-sm font-bold")}
          >
            {!inRange && address && !loadingAddress ? "Outside delivery zone" : "Use this address"}
          </Button>
        ) : (
          <div className="space-y-2 rounded-2xl border-2 border-primary/40 bg-primary/5 p-3 animate-in fade-in slide-in-from-bottom-1">
            <div className="flex items-start gap-2">
              <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-bold uppercase tracking-wider text-primary">
                  Confirm this address?
                </p>
                <p className="mt-0.5 text-sm font-medium text-foreground break-words">{address}</p>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  We'll save this exact spot and your GPS pin for delivery.
                </p>
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <Button
                type="button"
                variant="outline"
                onClick={() => setConfirming(false)}
                className="h-11 flex-1 rounded-full text-sm font-bold"
              >
                <Pencil className="h-4 w-4" />
                Adjust pin
              </Button>
              <Button
                type="button"
                onClick={() => {
                  const shortAddress = address.length > 60 ? `${address.slice(0, 60)}…` : address;
                  toast.success("Address saved", {
                    description: shortAddress,
                    duration: 3000,
                    closeButton: true,
                  });
                  onConfirm({ address, lat: position[0], lng: position[1] });
                }}
                className="h-11 flex-1 rounded-full text-sm font-bold"
              >
                <Check className="h-4 w-4" />
                Confirm
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AddressMapPicker;
